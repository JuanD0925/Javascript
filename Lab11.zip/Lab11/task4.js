const fetchCountry = async (alpha3Code) => {
    try {
      const res = await fetch(`https://restcountries.eu/rest/v2/alpha/${alpha3Code}`);
      return await res.json();
    } catch (error) {
      console.log(error);
    }
  };
  
  const fetchCountryAndNeighbors = async () => {
    const colombia = await fetchCountry("col");
  
    const neighbors = await Promise.all(
      colombia.borders.map((border) => fetchCountry(border))
    );
  
    console.log(neighbors);
  };
  
  fetchCountryAndNeighbors();
  