const onMyBirthday = (isKayoSick) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (!isKayoSick) {
          resolve(2); // 2 cakes
        } else {
          reject(new Error("I am sad")); // No cakes
        }
      }, 2000);
    });
  };
  
  // Kayo is not sick
  onMyBirthday(false)
    .then((result) => console.log(`I have ${result} cakes`))
    .catch((error) => console.log(error))
    .finally(() => console.log("Party"));
  
  // Kayo is sick
  onMyBirthday(true)
    .then((result) => console.log(`I have ${result} cakes`))
    .catch((error) => console.log(error))
    .finally(() => console.log("Party"));
  